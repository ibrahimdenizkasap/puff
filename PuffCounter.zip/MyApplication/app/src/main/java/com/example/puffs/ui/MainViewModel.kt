package com.example.puffs.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.puffs.data.Puff
import com.example.puffs.data.PuffRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.combine

class MainViewModel(app: Application): AndroidViewModel(app){
    private val repo = PuffRepository(app)

    val todayCount = repo.todayCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val todayPuffs = repo.todayPuffs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val weekTotal = repo.last7DaysTotal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val savedToday = repo.todaySavedCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val sessionCount = combine(todayCount, savedToday){ today, saved -> (today - saved).coerceAtLeast(0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val allPuffs = repo.all().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    fun addPuff() = viewModelScope.launch { repo.add() }
    fun addMany(n:Int) = viewModelScope.launch { repo.addMany(n) }
    fun undo(n:Int=1) = viewModelScope.launch { repo.undo(n) }
    fun saveSession() = viewModelScope.launch { repo.saveSession() }
}
