package com.example.puffs

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
// import androidx.compose.foundation.lazy.items // This might become unused
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState // Added import
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll // Added import
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.puffs.overlay.OverlayService
import com.example.puffs.ui.MainViewModel
import com.example.puffs.ui.theme.PuffsTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.rememberCoroutineScope
import com.example.puffs.util.importCsvFromUri
import kotlinx.coroutines.launch
import android.widget.Toast
// Removed duplicate imports for rememberLauncherForActivityResult, rememberCoroutineScope, launch, importCsvFromUri
import com.example.puffs.util.exportCsvToUri
import com.example.puffs.ui.GroupedTimeline
// Removed duplicate imports for foundation.layout, material3, unit.dp
import com.example.puffs.ui.SessionHistoryList



class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PuffsTheme { AppUI(vm) } }

        // Force system bars to your dark slate + light (white) icons
        window.statusBarColor = 0xFF0B0F14.toInt()       // top bar
        window.navigationBarColor = 0xFF0B0F14.toInt()   // bottom bar

        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.isAppearanceLightStatusBars = false       // false = white status icons
        controller.isAppearanceLightNavigationBars = false   // false = white nav icons
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Text(
                value,
                style = MaterialTheme.typography.displaySmall, // big number
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}


@Composable
fun AppUI(vm: MainViewModel){
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    exportCsvToUri(ctx, uri)
                    Toast.makeText(ctx, "Exported CSV", Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                    Toast.makeText(ctx, "Export failed: ${t.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            // (Optional) persist permission if you’ll reuse this URI later
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Throwable) {}

            scope.launch {
                try {
                    val added = importCsvFromUri(ctx, uri)
                    Toast.makeText(ctx, if (added>0) "Imported $added puffs" else "No timestamps found", Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                    Toast.makeText(ctx, "Import failed: ${t.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }


    // collect StateFlows from VM
    val todayCount by vm.todayCount.collectAsState()
    val todayPuffs by vm.todayPuffs.collectAsState()
    val weekTotal by vm.weekTotal.collectAsState()          // requires VM field from earlier step
    val sessionCount by vm.sessionCount.collectAsState()    // requires VM field from earlier step

    // Add ×N dialog state
    var showAddN by remember { mutableStateOf(false) }
    var nText by remember { mutableStateOf("3") }

    if (showAddN) {
        AlertDialog(
            onDismissRequest = { showAddN = false },
            title = { Text("Add ×N") },
            text = {
                OutlinedTextField(
                    value = nText,
                    onValueChange = { nText = it.filter(Char::isDigit).take(4) },
                    singleLine = true,
                    label = { Text("How many?") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = nText.toIntOrNull()?.coerceIn(1, 999) ?: 0
                    if (n > 0) vm.addMany(n)
                    showAddN = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAddN = false }) { Text("Cancel") } }
        )
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .padding(16.dp)
                .verticalScroll(rememberScrollState()), // Added verticalScroll
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("🫁 Puff Counter", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

            // stats
            // Top row: Current Session & Today
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Current Session",
                    value = sessionCount.toString(),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Today",
                    value = todayCount.toString(),
                    modifier = Modifier.weight(1f)
                )
            }

            // Full-width 7-Day Total card
            StatCard(
                title = "7-Day Total",
                value = weekTotal.toString(),
                modifier = Modifier
                    .fillMaxWidth()
            )

            // controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { vm.addPuff() },
                    modifier = Modifier.weight(1f)
                ) { Text("+1 Puff") }

                OutlinedButton(
                    onClick = { vm.undo() },
                    modifier = Modifier.weight(1f)
                ) { Text("Undo") }

                OutlinedButton(
                    onClick = { showAddN = true },
                    modifier = Modifier.weight(1f)
                ) { Text("Add ×N") }
            }


            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (!Settings.canDrawOverlays(ctx)) {
                            val i = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + ctx.packageName)
                            )
                            ctx.startActivity(i)
                        } else {
                            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2563EB), // bright blue
                        contentColor = Color.White          // white text
                    )
                ) { Text("Start Bubble") }

                OutlinedButton(onClick = { vm.saveSession() }) { Text("Save Session") }
            }



// Collect all puffs
            val allPuffs by vm.allPuffs.collectAsState()

            Text("Timeline", style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp, max = 360.dp) // contained height; both panes scroll
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left: Timeline (Time / Cumulative)
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    tonalElevation = 1.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    // optional header bar like the web app
                    Column {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Time", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("Cumulative", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Divider()
                        // The grouped timeline list itself
                        GroupedTimeline(
                            allPuffs = allPuffs,
                            daysBack = 7,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Right: Session History (Date / Puffs)
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    tonalElevation = 1.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    SessionHistoryList(
                        allPuffs = allPuffs,
                        daysBack = 7,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { exportLauncher.launch("puff_data.csv") },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) { Text("Export CSV") }

                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("text/*","text/csv")) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) { Text("Import CSV") }
            }
        }
    }
}
