package com.example.puffs.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PuffDao {
    @Insert suspend fun insert(puff: Puff)
    @Delete suspend fun delete(puff: Puff)

    @Query("SELECT * FROM puffs ORDER BY timestamp DESC")
    fun streamAll(): Flow<List<Puff>>

    @Query("SELECT COUNT(*) FROM puffs WHERE date(timestamp/1000,'unixepoch','localtime') = date('now','localtime')")
    fun todayCountFlow(): Flow<Int>

    @Query("SELECT * FROM puffs WHERE date(timestamp/1000,'unixepoch','localtime') = date('now','localtime') ORDER BY timestamp DESC")
    fun todayPuffsFlow(): Flow<List<Puff>>

    @Query("DELETE FROM puffs WHERE id IN (SELECT id FROM puffs ORDER BY timestamp DESC LIMIT :n)")
    suspend fun deleteLastN(n: Int)

    @Query("""
SELECT COUNT(*) FROM puffs 
WHERE date(timestamp/1000,'unixepoch','localtime') >= date('now','-6 days','localtime')
""")
    fun last7DaysTotalFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM puffs WHERE date(timestamp/1000,'unixepoch','localtime') = date('now','localtime')")
    suspend fun todayCountOnce(): Int

    @Query("SELECT timestamp FROM puffs")
    suspend fun allTimestampsOnce(): List<Long>

    @Query("SELECT * FROM puffs ORDER BY timestamp ASC")
    suspend fun streamAllOnce(): List<Puff>

}