package com.example.puffs.overlay

import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.LinearLayout
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import androidx.core.app.NotificationCompat
import com.example.puffs.MainActivity
import com.example.puffs.R
import com.example.puffs.data.PuffRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine


class OverlayService: Service(){
    private val scope = CoroutineScope(Dispatchers.Main)
    private lateinit var repo: PuffRepository
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var isOverlayAdded = false
    private var statsJob: Job? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    
    override fun onCreate(){
        super.onCreate()
        repo = PuffRepository(this)
        startForeground(1, buildNotif())
        showBubble()
    }

    override fun onDestroy() {
        super.onDestroy()
        bubble?.let {
            try { wm.removeView(it) } catch (_: Throwable) {}
        }
        bubble = null
        isOverlayAdded = false
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotif(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val chId = "puffs"
        nm.createNotificationChannel(NotificationChannel(chId, "Puffs", NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, chId)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(pi)
            .setOngoing(true)
            .addAction(0, getString(R.string.overlay_action_add), pendingBroadcast("ADD"))
            .addAction(0, getString(R.string.overlay_action_undo), pendingBroadcast("UNDO"))
            .build()
    }

    private fun pendingBroadcast(action:String): PendingIntent {
        val i = Intent("com.example.puffs.ACTION").putExtra("action", action)
        return PendingIntent.getBroadcast(this, action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Remove any existing overlay first
        bubble?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        bubble = null
        statsJob?.cancel()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, // Changed from FLAG_LAYOUT_INSET_DECOR
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100; y = 300
        }

        // Root row: [drag][content]
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        // Drag handle (easy grab)
        val dragHandle = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(20), dp(72))
            background = GradientDrawable().apply {
                setColor(0x33FFFFFF)
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }

        // Content column (buttons + stats)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(0xCC0B0F14.toInt())
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0x331F2937) // Removed .toInt()
            }
            background = bg
            setPadding(dp(10), dp(10), dp(10), dp(10))
            elevation = dp(6).toFloat()
        }

        // Buttons row: +1 / Undo / Save
        fun makeBtn(label: String) = Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            minWidth = dp(96); minHeight = dp(48)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val addBtn = makeBtn(getString(R.string.overlay_action_add)).apply { // Using string resource
            background = GradientDrawable().apply { setColor(0xFF10B981.toInt()); cornerRadius = dp(24).toFloat() }
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { scope.launch { repo.add() } }
        }
        val undoBtn = makeBtn(getString(R.string.overlay_action_undo)).apply { // Using string resource
            background = GradientDrawable().apply { setColor(0x00000000); setStroke(dp(2), 0x66E5E7EB); cornerRadius = dp(24).toFloat() } // Removed .toInt()
            setTextColor(0xFFE5E7EB.toInt())
            setOnClickListener { scope.launch { repo.undo() } }
        }
        val saveBtn = makeBtn(getString(R.string.overlay_action_save)).apply { // Using string resource
            background = GradientDrawable().apply { setColor(0x00000000); setStroke(dp(2), 0x66E5E7EB); cornerRadius = dp(24).toFloat() } // Removed .toInt()
            setTextColor(0xFFE5E7EB.toInt())
            setOnClickListener { scope.launch { repo.saveSession() } }
        }

        fun spacer(w:Int)= View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
        row.addView(addBtn); row.addView(spacer(6)); row.addView(undoBtn); row.addView(spacer(6)); row.addView(saveBtn)

        // Stats (Session only)
        val sessionView = TextView(this).apply {
            setTextColor(0xFFE5E7EB.toInt())
            textSize = 14f
            text = getString(R.string.overlay_session_initial_text) // Using string resource
        }

        column.addView(row)
        column.addView(spacer(6))
        column.addView(sessionView)

        root.addView(dragHandle)
        root.addView(column)

        // Drag only from the handle (buttons remain easy to tap)
        dragHandle.setOnTouchListener(object : View.OnTouchListener {
            private var initX = 0; private var initY = 0
            private var touchX = 0f; private var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { initX = params.x; initY = params.y; touchX = e.rawX; touchY = e.rawY; return true }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initX + (e.rawX - touchX).toInt()
                        params.y = initY + (e.rawY - touchY).toInt()
                        wm.updateViewLayout(root, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        v.performClick()
                        return true
                    }
                }
                return false
            }
        })

        // Long-press anywhere on column to close
        column.setOnLongClickListener { stopSelf(); true }

        wm.addView(root, params)
        bubble = root

        // Live session = todayCount - savedToday (from repo)
        statsJob = scope.launch {
            repo.todayCount().combine(repo.todaySavedCount()) { t, s -> (t - s).coerceAtLeast(0) }
                .collect { sessionView.text = getString(R.string.overlay_session_text, it) } // Using string resource
        }
    }
}
