package com.example.puffs.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [Puff::class, Session::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun puffDao(): PuffDao
    abstract fun sessionDao(): SessionDao

    companion object {
        @Volatile private var INSTANCE: AppDb? = null
        fun get(context: Context): AppDb = INSTANCE ?: synchronized(this){
            INSTANCE ?: Room.databaseBuilder(context, AppDb::class.java, "puffs.db")
                .addMigrations(object : Migration(1, 2) {
                    override fun migrate(db: SupportSQLiteDatabase) {
                        db.execSQL(
                            "CREATE TABLE IF NOT EXISTS sessions (" +
                                    "date TEXT NOT NULL PRIMARY KEY, " +
                                    "count INTEGER NOT NULL)"
                        )
                    }
                })
                .build().also{ INSTANCE = it }
        }
    }
}
