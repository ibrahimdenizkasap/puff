package com.example.puffs.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.map

class PuffRepository(ctx: Context) {
    private val db = AppDb.get(ctx)
    private val dao = db.puffDao()
    private val sess = db.sessionDao()

    fun todayCount(): Flow<Int> = dao.todayCountFlow()
    fun todayPuffs(): Flow<List<Puff>> = dao.todayPuffsFlow()
    fun all(): Flow<List<Puff>> = dao.streamAll()
    fun last7DaysTotal(): Flow<Int> = dao.last7DaysTotalFlow()
    fun todaySavedCount(): Flow<Int> = sess.todaySavedCountFlow().map { it ?: 0 }

    suspend fun add() = withContext(Dispatchers.IO){ dao.insert(Puff()) }
    suspend fun addMany(n:Int) = withContext(Dispatchers.IO) { repeat(n) { dao.insert(Puff()) } }
    suspend fun undo(n:Int=1) = withContext(Dispatchers.IO){ dao.deleteLastN(n) }

    suspend fun saveSession() = withContext(Dispatchers.IO){
        val today = java.time.LocalDate.now().toString()
        val c = dao.todayCountOnce()
        sess.upsert(Session(date = today, count = c))
    }
}
